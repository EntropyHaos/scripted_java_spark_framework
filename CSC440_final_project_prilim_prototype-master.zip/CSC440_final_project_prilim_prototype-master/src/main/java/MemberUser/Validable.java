package MemberUser;

public interface Validable {

    /**
     * Just to check if inputs are valid
     * @return
     */
    boolean isValid();
}
