package Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Model {
    private Map<String, Object> user;

    public Model() {
        this.user = new HashMap<>();
    }
    
    public int createUser(String memberName, String memberNumber, String memberStreetAddress, String memberCity, String memberState, long memberZipCode) {
        
        MemberTable usr = new MemberTable();
        
        usr.setMemberName(memberName);
        usr.setMemberNumber(memberNumber);
        usr.setMemberStreetAddress(memberStreetAddress);
        usr.setMemberCity(memberCity);
        usr.setMemberState(memberState);
        usr.setMemberZipCode(memberZipCode);
        user.put(memberNumber,usr);
        return 1;
    }
    
    public boolean checkUser(String memberIdToFind) {
        Iterator it = user.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            MemberTable u = (MemberTable)pair.getValue();
            if((u.getMemberNumber().equals(memberIdToFind)))
                return false;
        }
        return true;
    }

    public int updateUser(String memberName, String memberNumber, String memberStreetAddress, String memberCity, String memberState, long memberZipCode) {
        
        MemberTable usr = (MemberTable)user.get(memberNumber);
        
        usr.setMemberName(memberName);
        usr.setMemberNumber(memberNumber);
        usr.setMemberStreetAddress(memberStreetAddress);
        usr.setMemberCity(memberCity);
        usr.setMemberState(memberState);
        usr.setMemberZipCode(memberZipCode);
        user.put(memberNumber,usr);
        return 1;
    }

    public boolean removeUser(String memberNumber) {
        if(!checkUser(memberNumber)) {
            user.remove(memberNumber);
            return true;    
        }
        return false;
    }
    
    /**
     * This function creates a list of all users
     * @return
     */
    public List sendElements() {
        List<Object> ret = new ArrayList<>(user.values());
        return ret;
    }

    public List sendUsersId() {
        List<Object> ret = new ArrayList<>(user.keySet());
        return ret;
    }
}
