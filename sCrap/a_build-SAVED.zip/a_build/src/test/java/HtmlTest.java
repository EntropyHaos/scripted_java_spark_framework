//import models.UserModel;
import java.util.Collections;
import org.junit.Test;
import org.easymock.EasyMock;
import static org.easymock.EasyMock.expect;

public class HtmlTest {
    
    public HtmlTest() {
    }

    /**
     *
     * @author prash_000
     @Test
    public void getAllPostsIsHandledCorrectlyInHtmlOutput() {
        UserModel model = EasyMock.createMock(UserModel.class);
        expect(model.sendElements()).andReturn(Collections.EMPTY_LIST);
    }
     */

}
